# Code Blue Website

Vite + React + Tailwind starter for the Code Blue landing site.

## Quick start

1. Install dependencies:
```
npm install
```

2. Run dev server:
```
npm run dev
```

3. Build for production:
```
npm run build
```

Drop the `dist/` folder into Netlify or connect your GitHub and deploy via Netlify/Vercel.
