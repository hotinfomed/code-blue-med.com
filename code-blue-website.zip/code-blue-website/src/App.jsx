
/*
Code Blue - Single-file React + Tailwind website
Includes: Full landing site layout and branding constants.
*/

import React from "react";

/* Branding & Theme Constants */
export const BRANDING = {
  name: "Code Blue",
  tagline: "Medical Care Delivered — At Home",
  colors: {
    primary: "#0B5F7A",
    accent: "#7FB4C9",
    bg: "#F6FAFB",
    card: "#FFFFFF",
    text: "#0F1724"
  },
  fonts: {
    heading: "Inter, ui-sans-serif, system-ui, -apple-system, 'Segoe UI'",
    body: ""
  },
  logoIdea: {
    mark: "A simple medical cross combined with a subtle 'B' shape; rounded corners; soft teal/white",
    usage: "Use the primary color for marks on white, reversed white on primary for header bar"
  }
};

/* Marketing Video Script */
export const MARKETING_VIDEO_SCRIPT = `
(Soft piano intro, gentle hospital ambient underlay)

Doctor (warm, reassuring, Egyptian accent):
When a loved one needs care, every minute matters. Hello — I'm Dr. Ahmed, and this is Code Blue.

We bring licensed doctors and nurses to your home — quickly, safely, and with respect. No waiting rooms. No transportation. Just trusted care where patients are most comfortable: at home.

(Visual: patient opening the door to a smiling clinician in Code Blue uniform)

Doctor:
Using the app, you request a visit in seconds. Nearby verified clinicians get a quick alert and can accept the job. You'll get the provider's name, photo, and ETA before they arrive.

(Visual: App UI showing request flow, provider card)

Doctor:
From wound care to injections, follow-ups to urgent assessments, our network covers essential services with clear pricing and secure records.

(Visual: clinician performing care, app receipt)

Doctor:
For families who need reliability and dignity in care — Code Blue is here. Download the app today and bring care home.

(End card: Code Blue logo, tagline, App Store + Play badges, gentle chime)
`;

/* App Store / Play Store Copy */
export const APP_STORE_COPY = {
  short: "Premium home visits by licensed clinicians — request in minutes.",
  full: `Code Blue brings licensed clinicians to your door. Request urgent visits, routine follow-ups, wound care, injections and more — all through one easy app. See provider profiles, get ETAs, view visit notes and secure receipts. Trusted, verified, and available in your city. Download Code Blue and get care at home.`,
  keywords: ["home visit", "doctor at home", "nurse visit", "on-demand healthcare", "house call"]
};

/* Helper Components */
const Badge = ({ children }) => (
  <span className="inline-block px-3 py-1 text-sm font-medium rounded-full bg-white/60 border">{children}</span>
);

const Section = ({ id, children, className = "" }) => (
  <section id={id} className={`py-16 ${className}`}>{children}</section>
);

/* Main Website Component */
export default function App() {
  return (
    <div className="min-h-screen font-sans text-slate-900" style={{ backgroundColor: BRANDING.colors.bg, color: BRANDING.colors.text, fontFamily: BRANDING.fonts.heading }}>
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-40">
        <div className="max-w-6xl mx-auto flex items-center justify-between px-6 py-4">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ backgroundColor: BRANDING.colors.primary }}>
              <span className="text-white font-bold">CB</span>
            </div>
            <div>
              <div className="text-lg font-semibold">Code Blue</div>
              <div className="text-xs text-slate-500">Medical Care Delivered — At Home</div>
            </div>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm text-slate-700">
            <a href="#how" className="hover:underline">How it works</a>
            <a href="#providers" className="hover:underline">For Providers</a>
            <a href="#patients" className="hover:underline">For Patients</a>
            <a href="#pricing" className="hover:underline">Pricing</a>
            <a href="#faq" className="hover:underline">FAQ</a>
            <a href="#contact" className="hover:underline">Contact</a>
            <a href="#" className="ml-4 inline-block px-4 py-2 bg-gradient-to-r from-[rgba(11,95,122,1)] to-[rgba(127,180,201,1)] text-white rounded-lg">Request a Visit</a>
          </nav>
        </div>
      </header>

      {/* Hero */}
      <main className="max-w-6xl mx-auto px-6">
        <section className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center py-20">
          <div className="md:col-span-7">
            <Badge>Premium Healthcare</Badge>
            <h1 className="mt-6 text-4xl md:text-5xl font-extrabold leading-tight">Medical Care at Home — Fast, Private, Compassionate</h1>
            <p className="mt-4 text-lg text-slate-700">Code Blue connects you with licensed doctors and nurses for on-demand home visits. Book now or schedule a visit — get ETA, provider profiles, visit notes, and secure receipts.</p>
            <div className="mt-6 flex gap-3">
              <a href="#" className="px-5 py-3 rounded-lg bg-[rgba(11,95,122,1)] text-white font-medium">Request a Visit</a>
              <a href="#how" className="px-5 py-3 rounded-lg border">How it works</a>
            </div>
            <div className="mt-6 text-sm text-slate-600">Available 24/7 in supported cities. For enterprise or corporate requests, contact partnerships.</div>
          </div>
          <div className="md:col-span-5">
            <div className="rounded-xl shadow p-6 bg-white">
              <div className="text-sm text-slate-500">Request a Visit</div>
              <div className="mt-3">
                <label className="block text-xs text-slate-600">Service</label>
                <select className="w-full mt-2 p-3 border rounded">
                  <option>Urgent doctor visit</option>
                  <option>Nurse visit (injection / wound care)</option>
                  <option>Chronic follow-up</option>
                </select>
              </div>
              <div className="mt-3">
                <label className="block text-xs text-slate-600">Location</label>
                <input className="w-full mt-2 p-3 border rounded" placeholder="Enter address or enable location" />
              </div>
              <div className="mt-4 flex gap-2">
                <button className="flex-1 py-3 rounded bg-[rgba(127,180,201,1)] text-white">Request Now</button>
                <button className="flex-1 py-3 rounded border">Schedule</button>
              </div>
              <div className="mt-3 text-xs text-slate-500">Provider arrives with full PPE where required. Payments secured and receipts emailed.</div>
            </div>
          </div>
        </section>

        {/* How it works */}
        <Section id="how">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold">How Code Blue Works</h2>
            <p className="mt-3 text-slate-600">Five simple steps from request to recovery.</p>
          </div>

          <div className="mt-10 grid grid-cols-1 md:grid-cols-5 gap-6">
            <div className="md:col-span-1 bg-white p-6 rounded-lg shadow">
              <div className="text-2xl font-semibold">1</div>
              <div className="mt-2 text-slate-700">Request a visit via app</div>
              <div className="mt-1 text-sm text-slate-500">Choose service, confirm location</div>
            </div>
            <div className="md:col-span-1 bg-white p-6 rounded-lg shadow">
              <div className="text-2xl font-semibold">2</div>
              <div className="mt-2 text-slate-700">Nearest providers notified</div>
              <div className="mt-1 text-sm text-slate-500">Providers get a short beep & details</div>
            </div>
            <div className="md:col-span-1 bg-white p-6 rounded-lg shadow">
              <div className="text-2xl font-semibold">3</div>
              <div className="mt-2 text-slate-700">Confirm & track ETA</div>
              <div className="mt-1 text-sm text-slate-500">Provider photo, ETA, price estimate</div>
            </div>
            <div className="md:col-span-1 bg-white p-6 rounded-lg shadow">
              <div className="text-2xl font-semibold">4</div>
              <div className="mt-2 text-slate-700">Visit & care</div>
              <div className="mt-1 text-sm text-slate-500">Care delivered; visit logged</div>
            </div>
            <div className="md:col-span-1 bg-white p-6 rounded-lg shadow">
              <div className="text-2xl font-semibold">5</div>
              <div className="mt-2 text-slate-700">Rating & follow-up</div>
              <div className="mt-1 text-sm text-slate-500">Rate provider; view receipt</div>
            </div>
          </div>
        </Section>

        {/* For Providers */}
        <Section id="providers" className="bg-transparent">
          <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl font-bold">For Healthcare Providers</h3>
              <p className="mt-3 text-slate-600">Join Code Blue to deliver care on your schedule. Flexible shifts, verified patients, and a fair fee structure. Providers receive monthly statements and must settle platform fees within 5 days to remain active.</p>

              <ul className="mt-4 space-y-2 text-slate-700">
                <li>• Flexible earning — accept requests when available</li>
                <li>• Verified patient requests — no time-wasters</li>
                <li>• Provider support & training</li>
                <li>• Monthly billing with 5-day settlement policy</li>
              </ul>

              <div className="mt-6">
                <a className="px-5 py-3 rounded bg-[rgba(11,95,122,1)] text-white inline-block">Become a Provider</a>
              </div>
            </div>
            <div>
              <div className="bg-white rounded-lg p-6 shadow">
                <div className="text-sm text-slate-500">Provider Dashboard Preview</div>
                <div className="mt-3 grid grid-cols-2 gap-3">
                  <div className="p-3 border rounded">Online</div>
                  <div className="p-3 border rounded">Earnings</div>
                  <div className="p-3 border rounded">New Requests</div>
                  <div className="p-3 border rounded">Invoices</div>
                </div>
                <div className="mt-4 text-xs text-slate-500">Notification sample: New request — 60s to accept. Location: Downtown</div>
              </div>
            </div>
          </div>
        </Section>

        {/* For Patients */}
        <Section id="patients" className="">
          <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-8 items-center">
            <div>
              <img src="/placeholder-patient-visit.jpg" alt="home visit" className="rounded-lg shadow" />
            </div>
            <div>
              <h3 className="text-2xl font-bold">For Patients</h3>
              <p className="mt-3 text-slate-600">Request urgent or scheduled home visits from licensed clinicians. Get clear pricing, visit notes, and receipts for insurance claims where applicable.</p>
              <ul className="mt-4 text-slate-700 space-y-2">
                <li>• Urgent home visits</li>
                <li>• Routine follow-ups and chronic care</li>
                <li>• Wound care, injections, IVs (as permitted)</li>
                <li>• Secure medical records and receipts</li>
              </ul>
              <div className="mt-6">
                <a className="px-5 py-3 rounded bg-[rgba(127,180,201,1)] text-white inline-block">Request a Visit</a>
              </div>
            </div>
          </div>
        </Section>

        {/* Pricing */}
        <Section id="pricing">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold">Pricing</h2>
            <p className="mt-3 text-slate-600">Transparent pricing so patients and providers can plan care.</p>
          </div>

          <div className="mt-8 max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg shadow">
              <div className="text-xl font-semibold">Standard Visit</div>
              <div className="mt-2 text-slate-700">First 30 minutes — $XX</div>
              <div className="mt-3 text-sm text-slate-500">Extra time billed per 15 minutes</div>
            </div>
            <div className="bg-white p-6 rounded-lg shadow border-2 border-[rgba(11,95,122,0.08)]">
              <div className="text-xl font-semibold">Popular — Monthly</div>
              <div className="mt-2 text-slate-700">$20/month — priority queueing + discounted visits</div>
              <div className="mt-3 text-sm text-slate-500">Family add-on options available</div>
            </div>
            <div className="bg-white p-6 rounded-lg shadow">
              <div className="text-xl font-semibold">Provider Fees</div>
              <div className="mt-2 text-slate-700">Platform commission or fixed fee per accepted request</div>
              <div className="mt-3 text-sm text-slate-500">Monthly billing; settlement due within 5 days to avoid suspension</div>
            </div>
          </div>
        </Section>

        {/* About */}
        <Section id="about">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold">About Code Blue</h2>
            <p className="mt-3 text-slate-600">Founded to bring dignity, speed, and quality to home-based clinical care. We verify every provider, log every visit, and prioritize patient safety.</p>
          </div>
        </Section>

        {/* FAQ */}
        <Section id="faq">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-center">Frequently Asked Questions</h2>
            <div className="mt-6 space-y-4">
              <details className="bg-white p-4 rounded shadow">
                <summary className="font-semibold">How quickly can I get a provider?</summary>
                <p className="mt-2 text-slate-600">Most immediate requests are matched within minutes, depending on provider availability in your area.</p>
              </details>
              <details className="bg-white p-4 rounded shadow">
                <summary className="font-semibold">Are providers verified?</summary>
                <p className="mt-2 text-slate-600">Yes. All clinicians undergo credential checks and identity verification before they can accept visits.</p>
              </details>
              <details className="bg-white p-4 rounded shadow">
                <summary className="font-semibold">How is payment handled for providers?</summary>
                <p className="mt-2 text-slate-600">Providers receive monthly statements for platform fees and must settle within 5 days to avoid temporary suspension.</p>
              </details>
            </div>
          </div>
        </Section>

        {/* Contact */}
        <Section id="contact">
          <div className="max-w-4xl mx-auto grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl font-bold">Get in touch</h3>
              <p className="mt-3 text-slate-600">Support: support@codeblue.app<br/>Provider support: providers@codeblue.app<br/>Enterprise: enterprise@codeblue.app</p>
            </div>
            <div>
              <form className="bg-white p-6 rounded-lg shadow">
                <label className="block text-sm">Name</label>
                <input className="w-full mt-2 p-3 border rounded" />
                <label className="block text-sm mt-3">Email</label>
                <input className="w-full mt-2 p-3 border rounded" />
                <label className="block text-sm mt-3">Message</label>
                <textarea className="w-full mt-2 p-3 border rounded" rows={4} />
                <div className="mt-4">
                  <button className="px-4 py-2 rounded bg-[rgba(11,95,122,1)] text-white">Send Message</button>
                </div>
              </form>
            </div>
          </div>
        </Section>

        {/* Footer */}
        <footer className="mt-20 py-10">
          <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-start justify-between gap-6 px-6">
            <div>
              <div className="text-lg font-semibold">Code Blue</div>
              <div className="text-sm text-slate-600 mt-2">Medical Care Delivered — At Home</div>
              <div className="text-xs text-slate-500 mt-4">© {new Date().getFullYear()} Code Blue. All rights reserved.</div>
            </div>
            <div className="flex gap-6 text-sm text-slate-600">
              <a>Privacy</a>
              <a>Terms</a>
              <a>Careers</a>
            </div>
          </div>
        </footer>
      </main>
    </div>
  );
}
